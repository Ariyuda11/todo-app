const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const dbPath = path.join(__dirname, 'data.db');

const db = new sqlite3.Database(dbPath);

function run(sql, params=[]) {
  return new Promise((resolve, reject) => {
    db.run(sql, params, function(err){
      if(err) return reject(err);
      resolve(this);
    });
  });
}
function all(sql, params=[]) {
  return new Promise((resolve, reject) => {
    db.all(sql, params, (err, rows) => {
      if(err) return reject(err);
      resolve(rows);
    });
  });
}
function get(sql, params=[]) {
  return new Promise((resolve, reject) => {
    db.get(sql, params, (err, row) => {
      if(err) return reject(err);
      resolve(row);
    });
  });
}

async function migrate() {
  const sql = `
  CREATE TABLE IF NOT EXISTS todos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    description TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );
  `;
  await run(sql);
  console.log('Migration done');
}

async function seed() {
  await run(`INSERT INTO todos (title, description) VALUES (?, ?)`, ['Belajar Node.js', 'Baca dokumentasi Express & SQLite']);
  await run(`INSERT INTO todos (title, description) VALUES (?, ?)`, ['Buat tugas Asprak', 'Deploy aplikasi dan submit link']);
  console.log('Seed inserted');
}

async function allTodos() {
  return await all(`SELECT * FROM todos ORDER BY id DESC`);
}
async function getTodo(id) {
  return await get(`SELECT * FROM todos WHERE id = ?`, [id]);
}
async function createTodo(title, description) {
  await run(`INSERT INTO todos (title, description) VALUES (?, ?)`, [title, description]);
}
async function updateTodo(id, title, description) {
  await run(`UPDATE todos SET title = ?, description = ? WHERE id = ?`, [title, description, id]);
}
async function deleteTodo(id) {
  await run(`DELETE FROM todos WHERE id = ?`, [id]);
}

if (require.main === module) {
  const arg = process.argv[2];
  migrate().then(() => {
    if (arg === '--seed') seed();
  }).catch(console.error).finally(() => process.exit(0));
}

module.exports = { migrate, seed, allTodos, getTodo, createTodo, updateTodo, deleteTodo };