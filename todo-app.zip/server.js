const express = require('express');
const bodyParser = require('body-parser');
const db = require('./db');
const app = express();
const PORT = process.env.PORT || 3000;

app.set('view engine', 'ejs');
app.use(express.static('public'));
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

app.get('/', async (req, res) => {
  const todos = await db.allTodos();
  res.render('index', { todos });
});

app.get('/todos/new', (req, res) => {
  res.render('new');
});

app.post('/todos', async (req, res) => {
  const { title, description } = req.body;
  await db.createTodo(title, description);
  res.redirect('/');
});

app.get('/todos/:id/edit', async (req, res) => {
  const todo = await db.getTodo(req.params.id);
  if (!todo) return res.status(404).send('Not found');
  res.render('edit', { todo });
});

app.post('/todos/:id', async (req, res) => {
  const { title, description } = req.body;
  await db.updateTodo(req.params.id, title, description);
  res.redirect('/');
});

app.post('/todos/:id/delete', async (req, res) => {
  await db.deleteTodo(req.params.id);
  res.redirect('/');
});

app.get('/api/todos', async (req, res) => {
  res.json(await db.allTodos());
});

app.get('/api/todos/:id', async (req, res) => {
  const todo = await db.getTodo(req.params.id);
  if (!todo) return res.status(404).json({ error: 'Not found' });
  res.json(todo);
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});